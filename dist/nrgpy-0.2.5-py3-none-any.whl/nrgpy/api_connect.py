#!/bin/usr/python
#
"""
NRG Convert API location
    The token variable below will be used for nrg_convert_api calls if populated. 
    Otherwise, the token will have to be provided each time the nrg_convert_api class
    is called.
"""


nrgApiUrl = 'https://services.nrgsystems.com/api/Convert?code=yafm/4r/axuaMMGTP9SkBRNrpmEhrrM4B4sU6ehrXDG6bJaMpFhbIg=='
token=''
